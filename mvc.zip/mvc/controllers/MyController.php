<?php
/**
 * 
 */
include 'models/MyModel.php';
class MyController extends MyModel
{
	
	function __construct()
	{
		parent::__construct();

		if(isset($_SERVER['PATH_INFO']))
		{
				$action = strtolower($_SERVER['PATH_INFO']); 
				switch ($action) {
			case '/login':
			include 'views/login.php';
			if(isset($_POST['submit']))
			{
				$data = $_POST;

				$result = $this->Login($data,"user");

				//echo $result;
				if($result == 1)
				{ ?>
					<script type="text/javascript">

						window.location.href = 'dashboard';
					</script>
					<?php 
				}
				else
				{
					echo "404 ihsfd";
				}
				//print_r($data);
			}

				# code...
				break;
			case '/about':
			echo "about page";
				# code...
				break;
				case '/demo':

				echo "demo is ";
				# code...
				break;

				case '/dashboard':
			include 'views/dashboard.php';
			break;

			default:
				# code...
				break;
		}
	}

		else
		{
			echo "404 page not found ";
		}
	}
}

$obj = new MyController();

?>