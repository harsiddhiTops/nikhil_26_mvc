<?php
//echo "hello";

require  'controllers/Mycontroller.php';
?>