<?php
session_start();
 class MyModel
{
	public $conn = "";
	
	function __construct()
	{
	$this->conn = new mysqli("localhost","root","","nikhil_mvc");}

	public function Login($data,$tbl)
	{

		print_r($data);

		$email = $data['email'];

		$password = $data['password'];


	 $sql = "select * from $tbl where password = '$password' AND (name='$email' OR email = '$email' OR mobile_number = '$email' )";
	$result = $this->conn->query($sql);

		if($result->num_rows >= 1)
		{
				$_SESSION['email'] = $email;
				return 1;
		}
		else
		{
			return 0;
		}

}

}
?>